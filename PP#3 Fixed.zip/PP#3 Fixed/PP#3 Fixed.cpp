#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
#include <thread>
#include <ctime>
#include <vector>
#include <windows.h>
#include <psapi.h>

using namespace std;

// Check if a process is running
bool isProcessRunning(const string& processName) {
    DWORD processes[1024], needed, processCount;
    if (!EnumProcesses(processes, sizeof(processes), &needed)) {
        return false; // Error in getting processes
    }

    processCount = needed / sizeof(DWORD);

    for (unsigned int i = 0; i < processCount; ++i) {
        HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, processes[i]);
        if (hProcess) {
            TCHAR processNameBuffer[MAX_PATH];
            if (GetModuleBaseName(hProcess, NULL, processNameBuffer, MAX_PATH)) {
#ifdef UNICODE
                // Convert wide string to standard string
                wstring wideProcessName(processNameBuffer);
                string runningProcessName(wideProcessName.begin(), wideProcessName.end());
#else
                string runningProcessName(processNameBuffer);
#endif

                if (runningProcessName.find(processName) != string::npos) {
                    CloseHandle(hProcess);
                    return true; // Game process found
                }
            }
            CloseHandle(hProcess);
        }
    }
    return false; // No game process found
}

class Game {
private:
    string gameName;
    double gameTimeInSeconds; // Time in seconds
    string feedback;
    int rating;
    string datePlayed;
    string fullGameName;

public:
    Game(const string& name) : gameName(name), gameTimeInSeconds(0), rating(0), feedback("") {
        // Map the process names to their full game names
        if (gameName == "DDSS.exe") {
            fullGameName = "Dale and Dawson Supply Simulator";
        }
        else if (gameName == "Frostpunk2.exe") {
            fullGameName = "Frostpunk 2";
        }
        else if (gameName == "b1.exe") {
            fullGameName = "Black Myth Wukong";
        }
        else if (gameName == "GhostOfTsushima.exe") {
            fullGameName = "Ghost of Tsushima";
        }
        else if (gameName == "Oregon.exe") {
            fullGameName = "High On Life";
        }
    }

    string getGameName() const { return gameName; }
    string getFullGameName() const { return fullGameName; }
    double getGameTime() const { return gameTimeInSeconds; }
    string getFeedback() const { return feedback; }
    int getRating() const { return rating; }
    string getDatePlayed() const { return datePlayed; }

    void setFeedback(const string& feedbackText) { feedback = feedbackText; }
    void setRating(int ratingValue) { rating = ratingValue; }
    void setDatePlayed(const string& date) { datePlayed = date; }
    void setGameTime(double time) { gameTimeInSeconds = time; }

    void trackTime() {
        auto start = chrono::steady_clock::now();

        // Track time until the game closes
        while (isRunning()) {
            this_thread::sleep_for(chrono::seconds(3)); // Check every 3 seconds
        }

        // Game has closed, calculate total time
        auto end = chrono::steady_clock::now();
        chrono::duration<double> gameDuration = end - start;
        gameTimeInSeconds = gameDuration.count(); // Store total time in seconds
    }

    bool isRunning() {
        // Check if the game process is running
        return isProcessRunning(gameName);
    }

    // Prompt user for feedback after the game ends
    void promptReview() {
        // Get current date and time for review 
        time_t now = time(0);
        tm localTime;
        localtime_s(&localTime, &now); // Local time

        char buffer[80];
        strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", &localTime);
        datePlayed = string(buffer);

        // Convert game time from seconds to hours, minutes, and seconds
        int hours = static_cast<int>(gameTimeInSeconds) / 3600;
        int minutes = (static_cast<int>(gameTimeInSeconds) / 60) % 60;
        int seconds = static_cast<int>(gameTimeInSeconds) % 60;

        // Prompt user for rating and feedback
        cout << "Game Name: " << fullGameName << endl;
        cout << "Time Played: " << hours << " hours, " << minutes << " minutes, " << seconds << " seconds" << endl;
        cout << "Rate your experience (1-10): ";
        cin >> rating;
        cin.ignore();

        cout << "Please provide brief feedback on your gaming session: ";
        getline(cin, feedback);
    }

    // Save the review file
    void saveReview() const {
        ofstream file("game_reviews.txt", ios::app);
        if (file.is_open()) {
            file << "Game: " << fullGameName << "\n";
            file << "Date Played: " << datePlayed << "\n";

            // Convert game time from seconds to hours, minutes, and seconds
            int hours = static_cast<int>(gameTimeInSeconds) / 3600;
            int minutes = (static_cast<int>(gameTimeInSeconds) / 60) % 60;
            int seconds = static_cast<int>(gameTimeInSeconds) % 60;
            file << "Time Played: " << hours << " hours, " << minutes << " minutes, " << seconds << " seconds\n";
            file << "Rating: " << rating << "/10\n";
            file << "Feedback: " << feedback << "\n\n";
            file.close();

            // Print the message for the saved review
            cout << "Review for " << fullGameName << " saved.\n";
        }
        else {
            cout << "Unable to save review.\n";
        }
    }
};

int main() {
    vector<string> gameNames = { "DDSS.exe", "b1.exe", "Frostpunk2.exe", "GhostOfTsushima.exe", "Oregon.exe" }; // List of processes to check

    cout << "Begin Gaming! Looking for games...\n";

    // Continuously check if any game is running
    while (true) {
        bool anyGameRunning = false;

        for (const auto& gameName : gameNames) {
            if (isProcessRunning(gameName)) {
                anyGameRunning = true;
                cout << "Game " << gameName << " is running. Tracking time...\n";

                // Track the game's running time
                Game game(gameName);
                game.trackTime(); // Track time until game closes

                // Once the game is closed, prompt for review
                game.promptReview();
                game.saveReview();

                // Ask user if they want to continue or exit after the review is saved
                string userChoice;
                cout << "Type 'end' to close the program, or press Enter to continue looking for games: ";
                getline(cin, userChoice);
                if (userChoice == "end" || userChoice == "END") {
                    return 0; // Exit program
                }

                break; // Break out of the for loop
            }
        }

        if (!anyGameRunning) {
            // Display "checking" with the dots that reset every second
            for (int i = 0; i < 5; ++i) {
                cout << "\rNo game running. Checking";
                for (int j = 0; j <= i; ++j) {
                    cout << ".";
                }
                cout.flush();
                this_thread::sleep_for(chrono::seconds(1)); // Wait for 1 second
            }
            cout << "\rNo game running. Checking     "; // Clear the extra dots by overwriting
        }

        this_thread::sleep_for(chrono::seconds(3)); // Wait 3 seconds before checking again
    }

    return 0;
}
